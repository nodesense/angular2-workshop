import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {RouterModule} from "@angular/router";
import {HttpModule} from "@angular/http";

import { AppComponent }  from './app.component';

import {AboutComponent} from "./about/about.component";

import {FooterComponent} from "./footer.component";

import {HomeComponent} from "./home/home.component";


import {aboutRouting} from "./about/about.routing";
import {homeRouting} from "./home/home.routing";

import {ProductListComponent} from "./product/product-list.component";
import {productRouting} from "./product/product.routing";

import {ProductService} from "./product/product.service";
import {ByYearPipe} from "./product/product.pipes";

@NgModule({
  imports: [ 
    BrowserModule,
    RouterModule,
    HttpModule,

    aboutRouting,
    homeRouting,
    productRouting
    ],

  declarations: [ 
      AppComponent,
      AboutComponent,
      FooterComponent,
      HomeComponent,
      ProductListComponent,
      ByYearPipe
  ],

  providers: [ProductService],

  bootstrap: [ 
    AppComponent,
    FooterComponent
     ]
})
export class AppModule { }
