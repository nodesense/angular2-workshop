import {Injectable} from "@angular/core";
import {Http, Response} from "@angular/http";

@Injectable()
export class ProductService {
    constructor(private http:Http) {
        console.log("new ProductService created");
    }

    getProducts(): any {
        return  this.http.get('http://localhost:7070/api/products');
    }


}