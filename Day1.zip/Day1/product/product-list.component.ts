import {Component, OnInit} from "@angular/core";
import {Http, Response} from "@angular/http";
import {ProductService} from "./product.service";

@Component({
    templateUrl: 'app/product/product-list.component.html'
})
export class ProductListComponent implements OnInit{
    products: any = [];

    constructor(private productService: ProductService) {

    }

    ngOnInit() {
        console.log("ngOnInit");
        this.productService.getProducts()
        .subscribe((response: Response) => {
            this.products = response.json();
            //console.log(this.products);
        })
    }

    ngOnDestroy() {
        console.log("ngOnDestroy");
    }
}