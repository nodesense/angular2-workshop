import {RouterModule, Routes} from "@angular/router";
import {ProductListComponent} from "./product-list.component";

const routes: Routes = [
    {
        path: 'products/list',
        component: ProductListComponent
    }
]

export const productRouting = RouterModule.forRoot(routes);

