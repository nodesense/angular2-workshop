import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `<h1>ProductApp</h1>
           <nav>
            <a routerLink="/">Home</a>
            <a routerLink="/products/list">Products</a>
            <a routerLink="/about">About</a>
           </nav>

           <router-outlet></router-outlet>     

    `
})
export class AppComponent { }

