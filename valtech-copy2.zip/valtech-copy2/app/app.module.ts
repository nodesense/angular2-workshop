import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule} from '@angular/router';

import {LocationStrategy, HashLocationStrategy} from "@angular/common";


import {ProductModule} from "./product/product.module";

import { AppComponent }  from './app.component';
import {AboutComponent} from "./about/about.component";

import {HomeComponent} from "./home.component";
import {aboutRouting} from "./about/about.routing";
import {homeRouting} from "./app.routing";

import {API_END_POINT} from "./app.config";

import {CartModule} from "./cart/cart.module";

@NgModule({
  imports: [ 
    BrowserModule,
    RouterModule,
    ProductModule,
    CartModule,
    homeRouting,
    aboutRouting
     ],
  declarations: [ 
    AppComponent,
    AboutComponent,
    HomeComponent
    ],

  providers : [
    {
      provide: 'apiEndPoint',
      useValue: API_END_POINT
    }
  ],

  bootstrap: [ AppComponent ]
})
export class AppModule { }
