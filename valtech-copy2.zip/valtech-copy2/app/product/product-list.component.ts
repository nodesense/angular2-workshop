import {Component, OnInit} from "@angular/core";

import {ProductService} from "./product.services";

import {CartStorageService} from "../cart/cart.services";

import "rxjs/Rx";

@Component({
    selector: 'product-list',
    templateUrl : 'app/product/templates/product-list.component.html'//,
 //  providers: [ProductService]
})
export class ProductListComponent implements OnInit {
    
    products: any;

    years:any = [2010, 2011, 2012, 2013, 2014, 2015, 2016];

    //two way binding for select
    year: any = "";

    constructor(private productService:ProductService,
                private cartService: CartStorageService) {
        
        console.log("product list component created");
    }

    ngOnInit() {
        console.log("ngOnInit on Product List");
         this.productService.getProducts()
         .subscribe((data: any) => {
             this.products = data; 
             console.log(" got products ");

         }
         );

         console.log("assuming got products ");

    }

    addToPurchaseList($event:any) {
        console.log("addToPurchaseList at list component ", $event);
        this.cartService.addProduct($event);
    }
  

    ngOnDestroy() {
          console.log("product destroy called");
    }
}