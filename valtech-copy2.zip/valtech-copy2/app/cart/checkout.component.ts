import {Component, OnInit, Inject, Attribute} from "@angular/core";
import {ActivatedRoute, Params} from "@angular/router";

import {CartStorageService} from "../cart/cart.services";
import {Http, Response} from "@angular/http";

import { FormGroup, FormControl, Validators, 
    FormBuilder, Validator, AbstractControl } 
    from '@angular/forms';


import "rxjs/Rx";


@Component({
    templateUrl: 'app/cart/templates/checkout.component.html'
})
export class CheckoutComponent implements OnInit {
    products: any = [];
    states:any = [];
    cities:any = [];

    form: FormGroup;

    fullNameControl:FormControl;
    stateControl:FormControl;
    cityControl:FormControl;
    countryControl:FormControl;

    address: any = {};
    offer : any = {};

    submitted:boolean = false;

    constructor(private cartStorageSevice: CartStorageService, 
                private route: ActivatedRoute,
                private httpClient: Http,
                @Inject("apiEndPoint") private apiEndPoint: string,
                formBuilder: FormBuilder
    ) {
        this.products = cartStorageSevice.getProducts();

        this.fullNameControl = new FormControl("", Validators.required);
        this.stateControl = new FormControl("");
        this.cityControl = new FormControl("");
        this.countryControl = new FormControl("");

         this.form = formBuilder.group({
            "fullName": this.fullNameControl,
            "state": this.stateControl,
            "city": this.cityControl,
            "country": this.countryControl
        });

    }

    generateOddNumber() {
        let promise:Promise<number> = new Promise<number>(
            function(resolve, reject) {
                setTimeout(function(){
                    let n:number = Math.floor(Math.random() * 100);
                    if (n % 2 == 0) {
                        reject("could not generate, better luck next time");
                    } else {
                        resolve(n);
                    }
                }, 2000);
            }
        );
        return promise;
    }

    ngOnInit() {     
        this.generateOddNumber()
        .then(function(n){
            console.log("got value ", n);
        })
        .catch(function(err){
            console.log("got error ", err);
        })

        /*
        this.httpClient.get(this.apiEndPoint + '/api/states')
        .map((response : Response) => response.json())
        .subscribe((data : any) => {
            this.states = data;
        })

        this.httpClient.get(this.apiEndPoint + '/api/cities')
        .map((response : Response) => response.json())
        .subscribe((data : any) => {
            this.cities = data;
        })*/

        var self = this;

        Promise.all([
            this.httpClient.get(this.apiEndPoint + '/api/states')
            .map((response : Response) => response.json())
            .toPromise(),

            this.httpClient.get(this.apiEndPoint + '/api/cities')
            .map((response : Response) => response.json())
            .toPromise()
        ])
        .then(function(results){

            self.states = results[0];
            self.cities = results[1];
        })

        this.offer.discount = this.route.snapshot.params["discount"];
        this.offer.coupon = this.route.snapshot.params["coupon"];
    }

    onSubmit() {
        this.submitted = true;
    }

    isSaved() {
        return this.submitted;
    }
}