import {RouterModule, Routes} from "@angular/router";
import {CartComponent} from "./cart.component";

import {CheckoutComponent} from "./checkout.component";

const routes: Routes = [
    {
        path: 'cart',
        component: CartComponent
    },

    {
        path: 'cart/checkout',
        component: CheckoutComponent
    }
];


export const cartRouting = RouterModule.forRoot(routes);
