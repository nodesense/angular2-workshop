import {NgModule} from "@angular/core";

import {CommonModule} from "@angular/common";
import {RouterModule} from "@angular/router";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";

import {cartRouting} from "./cart.routing";
import {CartComponent} from "./cart.component";


import {CheckoutComponent} from "./checkout.component";


import {CartStorageService, CartLocalStorageService, CartSessionStorageService} 
from "./cart.services"

@NgModule({
    imports: [
        CommonModule, 
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        cartRouting
        ],

    declarations: [
        CartComponent,
        CheckoutComponent
        ],

    providers: [
           {
               provide: CartStorageService,
               useClass: CartLocalStorageService
           }
        ]
})
export class CartModule {

}