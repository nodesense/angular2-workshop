import {Component} from "@angular/core";

@Component({
  template: `
        <h2>Home Page</h2>
  `  
})
export class HomeComponent {
    
}