import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
                <nav>
                    <a routerLink="/products" >Products</a>
                    <a routerLink="/cart" >Cart</a>
                    <a routerLink="/about" >About</a>
                </nav>

                <h1>ProductApp</h1>

                <!-- container for dynamic view -->
                <router-outlet>
                </router-outlet>

    `
})
export class AppComponent { }
