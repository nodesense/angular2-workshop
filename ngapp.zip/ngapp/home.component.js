"use strict";
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var fs = require("file-system");
var camera = require("camera");
var HomeComponent = (function () {
    function HomeComponent(router) {
        this.router = router;
    }
    HomeComponent.prototype.ngOnInit = function () {
        // this.myImageRef.nativeElement.src = "~/files/Test.png";
    };
    HomeComponent.prototype.onAbout = function () {
        this.router.navigate(['about']);
    };
    HomeComponent.prototype.onProducts = function () {
        this.router.navigate(['products']);
    };
    HomeComponent.prototype.onSearch = function () {
        this.router.navigate(['products/search']);
    };
    HomeComponent.prototype.onCamera = function () {
        var availability = camera.isAvailable();
        if (availability) {
            camera.takePicture().then(function (result) {
                // result is ImageSource
                console.log("Got picture");
                var folder = fs.knownFolders.documents();
                console.log('folder - ', folder); // => object
                var path = fs.path.join(folder.path, "Test.png");
                console.log('path - ', path); // => correct path
                var saved = result.saveToFile(path, "png"); // ### Execution stops here.
                console.log('saved - ', saved);
            }, function (err) {
                console.log("Error in taking picture");
            });
        }
    };
    __decorate([
        core_1.ViewChild("myImage"), 
        __metadata('design:type', core_1.ElementRef)
    ], HomeComponent.prototype, "myImageRef", void 0);
    HomeComponent = __decorate([
        core_1.Component({
            selector: 'home',
            template: "\n        <StackLayout>\n            <Label text=\"Welcome\" class=\"title\">\n            </Label>\n \n    <StackLayout orientation=\"horizontal\">\n        <Button text=\"About\" (tap)=\"onAbout()\"></Button>\n\n        <Button text=\"Products\" (tap)=\"onProducts()\"></Button>\n\n\n        <Button text=\"Search\" (tap)=\"onSearch()\"></Button>\n\n         <Button text=\"Camera\" (tap)=\"onCamera()\"></Button>\n\n\n         <Image   #myImage src=\"res://logo\" >\n         </Image>\n        \n    </StackLayout>\n    \n            \n        </StackLayout>\n    "
        }), 
        __metadata('design:paramtypes', [router_1.Router])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map