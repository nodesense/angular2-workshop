"use strict";
var core_1 = require("@angular/core");
var platform_1 = require("nativescript-angular/platform");
var forms_1 = require("nativescript-angular/forms");
var http_1 = require("nativescript-angular/http");
var router_1 = require("nativescript-angular/router");
var app_component_1 = require("./app.component");
var about_component_1 = require("./about/about.component");
var home_component_1 = require("./home.component");
var contact_address_component_1 = require("./about/contact-address.component");
var product_module_1 = require("./product/product.module");
var app_routing_1 = require("./app.routing");
var API_END_POINT = "http://10.0.3.2:7070";
var anyGlobal = global;
if (!anyGlobal.android) {
    API_END_POINT = "http://krish.local:7070";
}
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_1.NativeScriptModule,
                forms_1.NativeScriptFormsModule,
                http_1.NativeScriptHttpModule,
                router_1.NativeScriptRouterModule,
                router_1.NativeScriptRouterModule.forRoot(app_routing_1.routes),
                product_module_1.ProductModule
            ],
            declarations: [
                app_component_1.AppComponent,
                about_component_1.AboutComponent,
                home_component_1.HomeComponent,
                contact_address_component_1.ContactAddressComponent
            ],
            bootstrap: [
                app_component_1.AppComponent
            ],
            providers: [
                {
                    provide: 'apiEndPoint',
                    useValue: API_END_POINT
                }
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map