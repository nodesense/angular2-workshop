import {AboutComponent} from "./about/about.component";
import {HomeComponent} from "./home.component";

import {ContactAddressComponent} from "./about/contact-address.component";

export const routes = [
    {
        path: '',
        component : HomeComponent
    },

    {
        path: 'about',
        component : AboutComponent
    }
]