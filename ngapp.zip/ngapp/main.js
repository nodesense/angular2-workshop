"use strict";
// this import should be first in order to load some required settings (like globals and reflect-metadata)
var platform_1 = require("nativescript-angular/platform");
//import { NgModule } from "@angular/core";
//import { AppComponent } from "./app.component";
/*
@NgModule({
    declarations: [AppComponent],
    bootstrap: [AppComponent],
    imports: [NativeScriptModule],
})
class AppComponentModule {}
*/
var app_module_1 = require("./app.module");
platform_1.platformNativeScriptDynamic().bootstrapModule(app_module_1.AppModule);
var appSettings = require("application-settings");
appSettings.setBoolean("boolKey", true);
var boolValue = appSettings.getBoolean("boolKey", false);
console.log("Value is ", boolValue);
var token = appSettings.getString("Token");
console.log("token is after set", token);
appSettings.setString("Token", "XYZDfdfdsafdsffadfda");
var token = appSettings.getString("Token");
console.log("token is ", token);
var file_test_1 = require("./file-test");
//createFile();
file_test_1.readFromFile();
//# sourceMappingURL=main.js.map