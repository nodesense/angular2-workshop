import {Component, OnInit, Input, Output, EventEmitter} from "@angular/core";


@Component({
    selector: 'contact-address',
    template: `
        <StackLayout>
            <Label text="Address" class="title">
            </Label>


            <Label [text]="address.city">
            </Label>
            <Label [text]="address.state">
            </Label>
            <Label [text]="address.country">
            </Label>

            <Button text="Contact Us" (tap)="onContact()"></Button>
            
        </StackLayout>
    `
})
export class ContactAddressComponent {
     
    @Input()
    address: any = {};

    @Output()
    onContactTapped: EventEmitter<any> = new EventEmitter<any>();

    onContact() {
        alert("contact tapped");
        console.log("contact tapped");

        this.onContactTapped.emit(this.address);
    }
}