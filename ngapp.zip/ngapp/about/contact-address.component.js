"use strict";
var core_1 = require("@angular/core");
var ContactAddressComponent = (function () {
    function ContactAddressComponent() {
        this.address = {};
        this.onContactTapped = new core_1.EventEmitter();
    }
    ContactAddressComponent.prototype.onContact = function () {
        alert("contact tapped");
        console.log("contact tapped");
        this.onContactTapped.emit(this.address);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], ContactAddressComponent.prototype, "address", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', core_1.EventEmitter)
    ], ContactAddressComponent.prototype, "onContactTapped", void 0);
    ContactAddressComponent = __decorate([
        core_1.Component({
            selector: 'contact-address',
            template: "\n        <StackLayout>\n            <Label text=\"Address\" class=\"title\">\n            </Label>\n\n\n            <Label [text]=\"address.city\">\n            </Label>\n            <Label [text]=\"address.state\">\n            </Label>\n            <Label [text]=\"address.country\">\n            </Label>\n\n            <Button text=\"Contact Us\" (tap)=\"onContact()\"></Button>\n            \n        </StackLayout>\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], ContactAddressComponent);
    return ContactAddressComponent;
}());
exports.ContactAddressComponent = ContactAddressComponent;
//# sourceMappingURL=contact-address.component.js.map