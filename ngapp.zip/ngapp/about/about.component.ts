import {Component, OnInit} from "@angular/core";

@Component({
    selector: 'about',
    template: `
        <StackLayout>
            <Label text="About Us" class="title">
            </Label>

            <contact-address [address]="headOffice" 
                (onContactTapped)="contactMe($event);"
            ></contact-address>

            <contact-address [address]="branchOffice"></contact-address>


            <Label [text]="state">
            </Label>
            <Label [text]="country">
            </Label>
            
        </StackLayout>
    `
})
export class AboutComponent {
    state:string = "MP";
    country: string = "India";

    headOffice: any = {};

    branchOffice: any = {};

    constructor() {
        this.headOffice = {
            state: 'KA',
            city: 'Bangalore',
            country: 'IN'
        }

        this.branchOffice = {
            state: 'KA',
            city: 'Mysore',
            country: 'IN'
        }
    }


    contactMe(address : any) {
        alert("message from " + address.state);
    }

}