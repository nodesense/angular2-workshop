"use strict";
var core_1 = require("@angular/core");
var AboutComponent = (function () {
    function AboutComponent() {
        this.state = "MP";
        this.country = "India";
        this.headOffice = {};
        this.branchOffice = {};
        this.headOffice = {
            state: 'KA',
            city: 'Bangalore',
            country: 'IN'
        };
        this.branchOffice = {
            state: 'KA',
            city: 'Mysore',
            country: 'IN'
        };
    }
    AboutComponent.prototype.contactMe = function (address) {
        alert("message from " + address.state);
    };
    AboutComponent = __decorate([
        core_1.Component({
            selector: 'about',
            template: "\n        <StackLayout>\n            <Label text=\"About Us\" class=\"title\">\n            </Label>\n\n            <contact-address [address]=\"headOffice\" \n                (onContactTapped)=\"contactMe($event);\"\n            ></contact-address>\n\n            <contact-address [address]=\"branchOffice\"></contact-address>\n\n\n            <Label [text]=\"state\">\n            </Label>\n            <Label [text]=\"country\">\n            </Label>\n            \n        </StackLayout>\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], AboutComponent);
    return AboutComponent;
}());
exports.AboutComponent = AboutComponent;
//# sourceMappingURL=about.component.js.map