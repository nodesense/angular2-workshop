// this import should be first in order to load some required settings (like globals and reflect-metadata)
import { platformNativeScriptDynamic, NativeScriptModule } from "nativescript-angular/platform";
//import { NgModule } from "@angular/core";
//import { AppComponent } from "./app.component";
/*
@NgModule({
    declarations: [AppComponent],
    bootstrap: [AppComponent],
    imports: [NativeScriptModule],
})
class AppComponentModule {}
*/
import {AppModule} from "./app.module";

platformNativeScriptDynamic().bootstrapModule(AppModule);

var appSettings = require("application-settings");

appSettings.setBoolean("boolKey", true);
var boolValue = appSettings.getBoolean("boolKey", false);

console.log("Value is ", boolValue);

var token = appSettings.getString("Token");

console.log("token is after set", token)

appSettings.setString("Token", "XYZDfdfdsafdsffadfda");
var token = appSettings.getString("Token");

console.log("token is ", token)

import {createFile, readFromFile} from "./file-test";

//createFile();

readFromFile();