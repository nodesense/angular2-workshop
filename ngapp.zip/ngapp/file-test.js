"use strict";
var fs = require("file-system");
var documents = fs.knownFolders.documents();
var testPath = "///test.txt";
// Get a normalized path such as <folder.path>/test.txt from <folder.path>///test.txt
var normalizedPath = fs.path.normalize(documents.path + testPath);
var separator = fs.path.separator;
console.log("normalized ", normalizedPath);
console.log("separator ", separator);
function createFile() {
    var documents = fs.knownFolders.documents();
    var path = fs.path.join(documents.path, "FileFromPath.txt");
    var file = fs.File.fromPath(path);
    // Writing text to the file.
    file.writeText("Something")
        .then(function () {
        // Succeeded writing to the file.
        console.log("file created successfully");
    }, function (error) {
        // Failed to write to the file.
        console.log("failed to create file");
    });
}
exports.createFile = createFile;
function readFromFile() {
    var documents = fs.knownFolders.documents();
    var myFile = documents.getFile("FileFromPath.txt");
    // Getting back the contents of the file.
    myFile.readText()
        .then(function (content) {
        console.log("Content is ", content);
    }, function (error) {
        // Failed to read from the file.
        console.log("failed to read content  ", error);
    });
}
exports.readFromFile = readFromFile;
//# sourceMappingURL=file-test.js.map