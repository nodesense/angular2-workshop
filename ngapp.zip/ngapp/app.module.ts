import {NgModule} from "@angular/core";

import {NativeScriptModule} from "nativescript-angular/platform";
import {NativeScriptFormsModule} from "nativescript-angular/forms";
import {NativeScriptHttpModule} from "nativescript-angular/http";
import {NativeScriptRouterModule} from "nativescript-angular/router";

import {AppComponent} from "./app.component";
import {AboutComponent} from "./about/about.component";
import {HomeComponent} from "./home.component";

import {ContactAddressComponent} from "./about/contact-address.component";

import {ProductModule} from "./product/product.module";

import {routes} from "./app.routing";

let API_END_POINT = "http://10.0.3.2:7070";
var anyGlobal = <any>global;

if (!anyGlobal.android) {
    API_END_POINT = "http://krish.local:7070";
}


@NgModule({
    imports: [
        NativeScriptModule,
        NativeScriptFormsModule,
        NativeScriptHttpModule,
        NativeScriptRouterModule,

        NativeScriptRouterModule.forRoot(routes),
        ProductModule
    ],

    declarations: [
        AppComponent,
        AboutComponent,
        HomeComponent,
        ContactAddressComponent
    ],

    bootstrap: [
        AppComponent
    ],

    providers: [
        {
            provide: 'apiEndPoint',
            useValue: API_END_POINT
        }
    ]
})
export class AppModule {
   
}