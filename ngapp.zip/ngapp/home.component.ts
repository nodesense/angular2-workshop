import {Component, OnInit, ViewChild, ElementRef} from "@angular/core";

import {Router} from "@angular/router";

import fs = require("file-system");
import camera = require("camera");

@Component({
    selector: 'home',
    template: `
        <StackLayout>
            <Label text="Welcome" class="title">
            </Label>
 
    <StackLayout orientation="horizontal">
        <Button text="About" (tap)="onAbout()"></Button>

        <Button text="Products" (tap)="onProducts()"></Button>


        <Button text="Search" (tap)="onSearch()"></Button>

         <Button text="Camera" (tap)="onCamera()"></Button>


         <Image   #myImage src="res://logo" >
         </Image>
        
    </StackLayout>
    
            
        </StackLayout>
    `
})
export class HomeComponent implements  OnInit {
    

  // similar to getViewById
  @ViewChild("myImage") myImageRef: ElementRef;

   constructor(private router: Router) {
        
    }

    ngOnInit() {
       // this.myImageRef.nativeElement.src = "~/files/Test.png";
  
    }

    public onAbout() {
        this.router.navigate(['about']);
    }


    public onProducts() {
        
        this.router.navigate(['products']);
    }


    public onSearch() {
        
        this.router.navigate(['products/search']);
    }

    public onCamera(){
        var availability = camera.isAvailable();

        if (availability) {
            camera.takePicture().then(result => {
                // result is ImageSource
                console.log("Got picture");


                var folder = fs.knownFolders.documents();
                console.log('folder - ', folder); // => object

                var path = fs.path.join(folder.path, "Test.png");
                console.log('path - ', path); // => correct path

                var saved = result.saveToFile(path, "png"); // ### Execution stops here.
                console.log('saved - ', saved);


            }, function(err) {
                console.log("Error in taking picture");
            });
        }
    }
}