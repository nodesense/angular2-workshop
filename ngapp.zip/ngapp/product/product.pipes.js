"use strict";
var core_1 = require("@angular/core");
var product_services_1 = require("./product.services");
var ByYearPipe = (function () {
    function ByYearPipe() {
    }
    ByYearPipe.prototype.transform = function (inputs, year) {
        if (!inputs)
            return;
        if (!year)
            return inputs;
        var results = [];
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].year == year) {
                results.push(inputs[i]);
            }
        }
        return results;
    };
    ByYearPipe = __decorate([
        core_1.Pipe({
            name: 'byYear'
        }), 
        __metadata('design:paramtypes', [])
    ], ByYearPipe);
    return ByYearPipe;
}());
exports.ByYearPipe = ByYearPipe;
var SearchProductPipe = (function () {
    function SearchProductPipe(productService) {
        this.productService = productService;
    }
    SearchProductPipe.prototype.transform = function (q) {
        console.log(q);
        return this.productService.searchProducts(q);
    };
    SearchProductPipe = __decorate([
        core_1.Pipe({
            name: 'searchProducts'
        }), 
        __metadata('design:paramtypes', [product_services_1.ProductService])
    ], SearchProductPipe);
    return SearchProductPipe;
}());
exports.SearchProductPipe = SearchProductPipe;
//# sourceMappingURL=product.pipes.js.map