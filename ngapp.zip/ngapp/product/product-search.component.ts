import { Component, OnInit, Inject } from "@angular/core";
import {Http, Response} from '@angular/http';
import {Router} from "@angular/router";

import { action } from "ui/dialogs";

import "rxjs/Rx";
import {ProductService} from "./product.services";

@Component({
  selector: "list",
  templateUrl: "product/product-search.component.html",
  styleUrls: []
})
export class ProductSearchComponent implements OnInit {
     products: Array<any> = [];
     searchText: string = '';

 constructor(private http:Http,
             @Inject("apiEndPoint") private apiEndPoint:string,
             private productService : ProductService,
             private router: Router
 ) {

 }

 ngOnInit() {
 
 console.log("calling ", this.apiEndPoint + "/api/brands");
  


  this.productService.getProducts()
  .subscribe( (data: any) => {
    console.log("got data ", data.length);
    this.products = data;
 
  })
 
  }

  editProduct(id) {
    console.log("test ", id);
    console.log("movig to ");
    this.router.navigate(["/products/edit/" + id]);
  }

  create() {
    this.router.navigate(["/products/create"]);
  }

  
}