"use strict";
var core_1 = require("@angular/core");
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
var dialogs_1 = require("ui/dialogs");
require("rxjs/Rx");
var product_services_1 = require("./product.services");
var ProductListComponent = (function () {
    function ProductListComponent(http, apiEndPoint, productService, router) {
        this.http = http;
        this.apiEndPoint = apiEndPoint;
        this.productService = productService;
        this.router = router;
        this.products = [];
        this.year = '';
    }
    ProductListComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("calling ", this.apiEndPoint + "/api/brands");
        this.productService.getProducts()
            .subscribe(function (data) {
            console.log("got data ", data.length);
            _this.products = data;
        });
    };
    ProductListComponent.prototype.editProduct = function (id) {
        console.log("test ", id);
        console.log("movig to ");
        this.router.navigate(["/products/edit/" + id]);
    };
    ProductListComponent.prototype.create = function () {
        this.router.navigate(["/products/create"]);
    };
    ProductListComponent.prototype.filter = function () {
        var _this = this;
        dialogs_1.action({
            message: "Select year to filter?",
            actions: ["All", "2010", "2011", "2012", "2013", "2014", "2015", "2016"],
            cancelButtonText: "Cancel"
        }).then(function (result) {
            console.log(result);
            if (result === "All") {
                _this.year = '';
            }
            else if (result == 'Cancel') {
                console.log("No change");
            }
            else {
                _this.year = result;
            }
        });
    };
    ProductListComponent = __decorate([
        core_1.Component({
            selector: "list",
            templateUrl: "product/product-list.component.html",
            styleUrls: []
        }),
        __param(1, core_1.Inject("apiEndPoint")), 
        __metadata('design:paramtypes', [http_1.Http, String, product_services_1.ProductService, router_1.Router])
    ], ProductListComponent);
    return ProductListComponent;
}());
exports.ProductListComponent = ProductListComponent;
//# sourceMappingURL=product-list.component.js.map