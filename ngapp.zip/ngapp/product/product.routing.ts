import {ProductListComponent} from "./product-list.component";
import {ProductSearchComponent} from "./product-search.component";

import {ProductEditComponent} from "./product-edit.component";

export const routes = [
    {
        path: 'products',
        component: ProductListComponent
    },

    {
        path: 'products/edit/:id',
        component: ProductEditComponent
    },


    {
        path: 'products/create',
        component: ProductEditComponent
    },

    {
        path: 'products/search',
        component: ProductSearchComponent
    }
    
]