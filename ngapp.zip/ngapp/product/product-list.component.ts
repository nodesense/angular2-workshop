import { Component, OnInit, Inject } from "@angular/core";
import {Http, Response} from '@angular/http';
import {Router} from "@angular/router";

import { action } from "ui/dialogs";

import "rxjs/Rx";
import {ProductService} from "./product.services";

@Component({
  selector: "list",
  templateUrl: "product/product-list.component.html",
  styleUrls: []
})
export class ProductListComponent implements OnInit {
     products: Array<any> = [];
     year: string = '';

 constructor(private http:Http,
             @Inject("apiEndPoint") private apiEndPoint:string,
             private productService : ProductService,
             private router: Router
 ) {

 }

 ngOnInit() {
 
 console.log("calling ", this.apiEndPoint + "/api/brands");
  


  this.productService.getProducts()
  .subscribe( (data: any) => {
    console.log("got data ", data.length);
    this.products = data;
 
  })
 
  }

  editProduct(id) {
    console.log("test ", id);
    console.log("movig to ");
    this.router.navigate(["/products/edit/" + id]);
  }

  create() {
    this.router.navigate(["/products/create"]);
  }

  filter() {
    action({
      message: "Select year to filter?",
      actions: ["All", "2010", "2011", "2012", "2013", "2014", "2015", "2016"],
      cancelButtonText: "Cancel"
     }).then((result) => {
        console.log(result);

        if (result === "All") {
          this.year = '';
        } else  if (result == 'Cancel') {
          console.log("No change");
        }
        else  {
           this.year = result;
        }
      });
  }
}