"use strict";
var core_1 = require("@angular/core");
var platform_1 = require("nativescript-angular/platform");
var forms_1 = require("nativescript-angular/forms");
var http_1 = require("nativescript-angular/http");
var router_1 = require("nativescript-angular/router");
var product_routing_1 = require("./product.routing");
var product_list_component_1 = require("./product-list.component");
var product_edit_component_1 = require("./product-edit.component");
var product_search_component_1 = require("./product-search.component");
var product_services_1 = require("./product.services");
var product_pipes_1 = require("./product.pipes");
var product_pipes_2 = require("./product.pipes");
var ProductModule = (function () {
    function ProductModule() {
    }
    ProductModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_1.NativeScriptModule,
                forms_1.NativeScriptFormsModule,
                http_1.NativeScriptHttpModule,
                router_1.NativeScriptRouterModule,
                router_1.NativeScriptRouterModule.forChild(product_routing_1.routes)
            ],
            declarations: [
                product_list_component_1.ProductListComponent,
                product_edit_component_1.ProductEditComponent,
                product_search_component_1.ProductSearchComponent,
                product_pipes_1.ByYearPipe,
                product_pipes_2.SearchProductPipe
            ],
            providers: [
                product_services_1.ProductService
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], ProductModule);
    return ProductModule;
}());
exports.ProductModule = ProductModule;
//# sourceMappingURL=product.module.js.map