"use strict";
var product_list_component_1 = require("./product-list.component");
var product_search_component_1 = require("./product-search.component");
var product_edit_component_1 = require("./product-edit.component");
exports.routes = [
    {
        path: 'products',
        component: product_list_component_1.ProductListComponent
    },
    {
        path: 'products/edit/:id',
        component: product_edit_component_1.ProductEditComponent
    },
    {
        path: 'products/create',
        component: product_edit_component_1.ProductEditComponent
    },
    {
        path: 'products/search',
        component: product_search_component_1.ProductSearchComponent
    }
];
//# sourceMappingURL=product.routing.js.map