import {NgModule} from "@angular/core";

import {NativeScriptModule} from "nativescript-angular/platform";
import {NativeScriptFormsModule} from "nativescript-angular/forms";
import {NativeScriptHttpModule} from "nativescript-angular/http";
import {NativeScriptRouterModule} from "nativescript-angular/router";

import {routes} from "./product.routing";

import {ProductListComponent} from "./product-list.component";
import {ProductEditComponent} from "./product-edit.component";
import {ProductSearchComponent} from "./product-search.component";

import {ProductService} from "./product.services";

import {ByYearPipe} from "./product.pipes";
import {SearchProductPipe} from "./product.pipes";

@NgModule({
    imports: [
            NativeScriptModule,
            NativeScriptFormsModule,
            NativeScriptHttpModule,
            NativeScriptRouterModule,

            NativeScriptRouterModule.forChild(routes)
        ],

    declarations: [
        ProductListComponent,
        ProductEditComponent,
        ProductSearchComponent,
        ByYearPipe,
        SearchProductPipe
    ],

    providers: [
        ProductService
    ]
})
export class ProductModule {
    
}