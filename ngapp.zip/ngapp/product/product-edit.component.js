"use strict";
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var product_services_1 = require("./product.services");
var dialogs_1 = require("ui/dialogs");
var page_1 = require("ui/page");
var ProductEditComponent = (function () {
    function ProductEditComponent(router, route, productService, page) {
        this.router = router;
        this.route = route;
        this.productService = productService;
        this.page = page;
        this.product = {};
        this.isLoading = false;
        this.title = "Edit";
        this.show = true;
    }
    ProductEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("product view component");
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg_login";
        this.route.params.forEach(function (params) {
            var id = params["id"];
            console.log("id is ", id);
            if (id) {
                _this.productService.getProduct(id)
                    .then(function (p) {
                    _this.product = p;
                    _this.title = "Edit " + p.name;
                });
            }
            else {
                _this.product = {};
            }
        });
    };
    ProductEditComponent.prototype.save = function () {
        var _this = this;
        this.showActivityIndicator();
        //this.router.navigate(['edit/' + this.product.id]);
        this.productService.saveProduct(this.product)
            .then(function (product) {
            _this.product = product;
            alert("Save");
            _this.showMenu();
            setTimeout(function () {
                _this.hideActivityIndicator();
            }, 5000);
        });
    };
    ProductEditComponent.prototype.showMenu = function () {
        dialogs_1.action({
            message: "What would you like to do?",
            actions: ["Share", "Log Off"],
            cancelButtonText: "Cancel"
        }).then(function (result) {
            if (result === "Share") {
            }
            else if (result === "Log Off") {
            }
        });
    };
    ProductEditComponent.prototype.showActivityIndicator = function () {
        this.isLoading = true;
    };
    ProductEditComponent.prototype.hideActivityIndicator = function () {
        this.isLoading = false;
    };
    ProductEditComponent.prototype.onTap = function () {
        alert("tapped");
    };
    ProductEditComponent = __decorate([
        core_1.Component({
            selector: 'product-view',
            templateUrl: 'product/product-edit.component.html'
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, product_services_1.ProductService, page_1.Page])
    ], ProductEditComponent);
    return ProductEditComponent;
}());
exports.ProductEditComponent = ProductEditComponent;
//# sourceMappingURL=product-edit.component.js.map