"use strict";
var core_1 = require("@angular/core");
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
require("rxjs/Rx");
var product_services_1 = require("./product.services");
var ProductSearchComponent = (function () {
    function ProductSearchComponent(http, apiEndPoint, productService, router) {
        this.http = http;
        this.apiEndPoint = apiEndPoint;
        this.productService = productService;
        this.router = router;
        this.products = [];
        this.searchText = '';
    }
    ProductSearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("calling ", this.apiEndPoint + "/api/brands");
        this.productService.getProducts()
            .subscribe(function (data) {
            console.log("got data ", data.length);
            _this.products = data;
        });
    };
    ProductSearchComponent.prototype.editProduct = function (id) {
        console.log("test ", id);
        console.log("movig to ");
        this.router.navigate(["/products/edit/" + id]);
    };
    ProductSearchComponent.prototype.create = function () {
        this.router.navigate(["/products/create"]);
    };
    ProductSearchComponent = __decorate([
        core_1.Component({
            selector: "list",
            templateUrl: "product/product-search.component.html",
            styleUrls: []
        }),
        __param(1, core_1.Inject("apiEndPoint")), 
        __metadata('design:paramtypes', [http_1.Http, String, product_services_1.ProductService, router_1.Router])
    ], ProductSearchComponent);
    return ProductSearchComponent;
}());
exports.ProductSearchComponent = ProductSearchComponent;
//# sourceMappingURL=product-search.component.js.map