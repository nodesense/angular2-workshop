import {Component, OnInit} from "@angular/core";

import {ActivatedRoute, Router, Params} from "@angular/router";


import {ProductService} from "./product.services";

import { action } from "ui/dialogs";

import { Page } from "ui/page";

@Component({
    selector: 'product-view',
    templateUrl: 'product/product-edit.component.html'
})
export class ProductEditComponent implements OnInit {

    product: any = {};
    isLoading: Boolean = false;

    title: string = "Edit";

    show:Boolean = true;

    constructor(private router: Router,
                private route: ActivatedRoute,
                private productService: ProductService,
                private page: Page
    ) {

    }

    ngOnInit() {
        console.log("product view component");

        
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg_login";
   

        this.route.params.forEach((params: Params) => {
            let id = params ["id"];
            console.log("id is ", id);
            if (id) {
                this.productService.getProduct(id)
                .then( (p: any) => { 
                    this.product = p;
                    this.title = "Edit " + p.name;
            })
            } else {
                this.product = {};
            }
        });
    }

    save() {
        this.showActivityIndicator();
        //this.router.navigate(['edit/' + this.product.id]);
        this.productService.saveProduct(this.product)
        .then( (product: any) => {
            this.product = product;
            alert("Save");
            this.showMenu();

            setTimeout( () => {
                this.hideActivityIndicator();
            }, 5000);
        })
    }

      showMenu() {
    action({
      message: "What would you like to do?",
      actions: ["Share", "Log Off"],
      cancelButtonText: "Cancel"
    }).then((result) => {
      if (result === "Share") {
        //this.share();
      } else if (result === "Log Off") {
       // this.logoff();
      }
    });
  }


  showActivityIndicator() {
    this.isLoading = true;
  }
  hideActivityIndicator() {
    this.isLoading = false;
  }


  onTap() {
      alert("tapped");
  }
}