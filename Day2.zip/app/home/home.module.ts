import {NgModule} from "@angular/core";
 import { RouterModule }       from '@angular/router';

import {homeRouting} from "./home.routing";

import {HomeComponent} from "./home.component";

@NgModule({
  imports:      [ RouterModule, homeRouting ],
  declarations: [ HomeComponent ]
})
export class HomeModule { }
