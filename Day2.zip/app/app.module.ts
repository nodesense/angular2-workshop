import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {RouterModule} from "@angular/router";
import {HttpModule} from "@angular/http";

import {FormsModule} from "@angular/forms"; 


import {Location} from "@angular/common";

import { AppComponent }  from './app.component';

//import {AboutComponent} from "./about/about.component";

import {FooterComponent} from "./footer.component";


//import {aboutRouting} from "./about/about.routing";

import {HomeComponent} from "./home/home.component";
import {homeRouting} from "./home/home.routing";

import {HomeModule} from "./home/home.module";
import {AboutModule} from "./about/about.module";

import {ProductListComponent} from "./product/product-list.component";
import {ProductEditComponent} from "./product/product-edit.component";
import {ProductCardComponent} from "./product/product-card.component";
import {ProductViewComponent} from "./product/product-view.component";

import {productRouting} from "./product/product.routing";

import {ProductService} from "./product/product.service";
import {ByYearPipe} from "./product/product.pipes";

//import {CartStorageSevice, CartLocalStorageService, CartSessionStorageService} from "./cart/cart.service";
//import {CartComponent} from "./cart/cart.component";
//import {cartRouting} from "./cart/cart.routing";
import {CartModule} from "./cart/cart.module";

@NgModule({
  imports: [ 
    BrowserModule,
    RouterModule,
    HttpModule,
    FormsModule,
    
    HomeModule,
    AboutModule,
    CartModule,

   // aboutRouting,
    //homeRouting,
    productRouting
    //,
    //cartRouting
    ],

  declarations: [ 
      AppComponent,
   //   AboutComponent,
      FooterComponent,
     // HomeComponent,
      
      ProductListComponent,
      ProductEditComponent,
      ProductCardComponent,
      ProductViewComponent,
      ByYearPipe//,

      //CartComponent
  ],

  providers: [
    Location,
    ProductService
    //,

    /*{
      provide: CartStorageSevice,
      useClass: CartSessionStorageService
    }*/
    
    ],

  bootstrap: [ 
    AppComponent,
    FooterComponent
     ]
})
export class AppModule { }
