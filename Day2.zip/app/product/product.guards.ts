import {CanDeactivate} from "@angular/router";

import {ProductEditComponent} from "./product-edit.component";

export class CanDeactivateProductComponentGuard implements CanDeactivate<ProductEditComponent> {
    canDeactivate(target: ProductEditComponent) {
        return false;
    }
}