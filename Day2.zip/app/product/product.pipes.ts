import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'byYear'
})
export class ByYearPipe implements PipeTransform {
     
    transform(inputs: any, year: string) {
        if (!year) {
            return inputs;
        }

        let results:any = [];

        for(var i = 0; i < inputs.length; i++) {
            if (inputs[i].year == year) {
                results.push(inputs[i]);
            }
        }

        return results;
    }
}