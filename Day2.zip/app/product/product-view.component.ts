import {ActivatedRoute, Router, Params} from "@angular/router";
import {Component, OnInit} from "@angular/core";

import {ProductService} from "./product.service";
import {Location} from "@angular/common";

@Component({
    templateUrl : 'app/product/product-view.component.html'
})
export class ProductViewComponent implements OnInit {
    product: any = {};
    
    constructor(private route:ActivatedRoute, 
                private router:Router,
                private productService: ProductService
                ) {

    }

    ngOnInit() {
        this.route.params.forEach((params: Params) => {
             let id = params['id']; 
             console.log("Product Id is ", id);

             if (id) {
                 this.productService.getProduct(id)
                 .then((data : any) => this.product = data);
             } else {
                 this.product = {};
             }
        });
    }

    ngOnDestroy() {

    }

    deleteProduct() {
        let self = this;

        this.productService.deleteProduct(this.product.id)
        .then(() => {
            self.router.navigate(["/products/list"]);
        })
    }

  
    
}
