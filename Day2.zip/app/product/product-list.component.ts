import {Component, OnInit} from "@angular/core";
import {Http, Response} from "@angular/http";
import {ProductService} from "./product.service";


import {CartStorageSevice} from "../cart/cart.service";


@Component({
    templateUrl: 'app/product/product-list.component.html'
})
export class ProductListComponent implements OnInit{
    products: any = [];

    year: string = '';
    years: [number] = [2010, 2011, 2012, 2013, 2014, 2015];

    constructor(private productService: ProductService,
                private cartStorageSevice: CartStorageSevice
    ) {

    }

    ngOnInit() {
        console.log("ngOnInit");
        this.productService.getProducts()
        .then((data : any) => this.products = data);

        /*.subscribe((response: Response) => {
            this.products = response.json();
            //console.log(this.products);
        })*/
    }

    ngOnDestroy() {
        console.log("ngOnDestroy");
    }

    addProductToShoppingCart($event: any) {
        console.log($event);

        this.cartStorageSevice.addProduct($event);
    }
}