import {ActivatedRoute, Router, Params} from "@angular/router";
import {Component, OnInit} from "@angular/core";

import {ProductService} from "./product.service";

@Component({
    templateUrl : 'app/product/product-edit.component.html'
})
export class ProductEditComponent implements OnInit {
    product: any = {};
    
    constructor(private route:ActivatedRoute, 
                private router:Router,
                private productService: ProductService) {

    }

    ngOnInit() {
        this.route.params.forEach((params: Params) => {
             let id = params['id']; 
             console.log("Product Id is ", id);

             if (id) {
                 this.productService.getProduct(id)
                 .then((data : any) => this.product = data);
             } else {
                 this.product = {};
             }
        });
    }

    ngOnDestroy() {

    }

   
   saveProduct($event: Event, productForm: any) {
       console.log("Valid ", productForm.valid);

        console.log(this.product.name);
        console.log(JSON.stringify(this.product));
        $event.preventDefault();

        this.productService.saveProduct(this.product)
        .then((data: any) => this.product = data);
    }
}
