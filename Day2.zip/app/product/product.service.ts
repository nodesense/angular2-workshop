import {Injectable} from "@angular/core";
import {Http, Response, Headers, RequestOptions} from "@angular/http";

import "rxjs/Rx";

@Injectable()
export class ProductService {
    apiEndPoint: string = "http://localhost:7070"
    constructor(private http:Http) {
        console.log("new ProductService created");
    }

    /*getProducts(): any {
        return  this.http.get('http://localhost:7070/api/products');
    }*/

    getProducts(): any {
        return this.http.get(this.apiEndPoint + '/api/products')
        .map((response: Response) => response.json())
        .toPromise();
    }

    getProduct(id: any): Promise<any> {
        return this.http.get(this.apiEndPoint + "/api/products/" + id)
        .map((response: Response) => response.json())
        .toPromise();
    }

    saveProduct(product: any) : Promise<any> {
        

         let body = JSON.stringify(product);

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        if (product.id) {
            return this.http.put(this.apiEndPoint + '/api/products/' + product.id, 
            body, 
            options)
            .map((response: Response) => response.json())
            .toPromise();
        } else { //create new product 
        
            return this.http.post(this.apiEndPoint + '/api/products', 
            body, 
            options)
            .map((response: Response) => response.json())
            .toPromise();
        }
    }

    deleteProduct(id: any): Promise<any> {
        return this.http.delete(this.apiEndPoint + '/api/products/' + id)
        .map((response: Response) => response.json())
        .toPromise();
    }


}