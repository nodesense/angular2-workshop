import { Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
    selector: 'product-card',
    templateUrl: 'app/product/product-card.component.html'
})
export class ProductCardComponent {
    @Input()
    product: any;

    @Output()
    addProductToCart: EventEmitter<any> = new EventEmitter<any>();

    constructor() { }

    addToCart() {
        this.addProductToCart.emit(this.product);
    }
     
}