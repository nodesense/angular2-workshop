import {RouterModule, Routes} from "@angular/router";

import {ProductListComponent} from "./product-list.component";
import {ProductEditComponent} from "./product-edit.component";
import {ProductViewComponent} from "./product-view.component";

const routes: Routes = [
    {
        path: 'products/list',
        component: ProductListComponent
    },

    {
        path: 'products/view/:id',
        component: ProductViewComponent
    },

    {
        path: 'products/edit/:id',
        component: ProductEditComponent
    },

    {
        path: 'products/create',
        component: ProductEditComponent
    }
]

export const productRouting = RouterModule.forRoot(routes);

