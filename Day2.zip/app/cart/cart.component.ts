import {Component} from "@angular/core";

import {CartStorageSevice} from "../cart/cart.service";

@Component({
    templateUrl: 'app/cart/cart.component.html'
})
export class CartComponent {
    products: any = [];

    constructor(private cartStorageSevice: CartStorageSevice) {
        this.products = cartStorageSevice.getProducts(); 
    }
}