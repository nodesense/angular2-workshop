import {NgModule} from "@angular/core";
import { RouterModule }       from '@angular/router';

import { CommonModule } from '@angular/common';



import {AboutComponent} from "./about.component";
import {aboutRouting} from "./about.routing";

@NgModule({
    imports: [RouterModule, CommonModule, aboutRouting],
    declarations: [AboutComponent]
})
export class AboutModule {

}