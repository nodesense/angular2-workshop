import {Component} from "@angular/core";

@Component({
    selector: 'about',
    template: `<h1>{{title}}</h1>
                <p>{{description}}</p>
                <p>Year : {{established}}</p>

                <ul>
                    <li *ngFor="let member of members">
                    {{member}}
                    </li>
                </ul>
               `
})
export class AboutComponent {
    title: string = "About Us";
    description:string;
    established: number = 2013;

    members : [string];

    constructor() {
        this.description = "We are MobileStore company";
        this.members = ["Karthik", "Santhosh"];
    }
}