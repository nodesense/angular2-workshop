import {RouterModule, Routes} from "@angular/router";
import {ProductListComponent} from "./product-list.component";

import {ProductHomeComponent} from "./product-home.component";

import {ProductEditComponent} from "./product-edit.component";
import {ProductSearchComponent} from "./product-search.component";

const routes:Routes = [
    {
        path: "products", // "/products"
        component : ProductHomeComponent,

        children: [
            {
                path: '', // /products
                //redirectTo : '/products/list'
            },

            {
                path: 'list', // /products/list
                component: ProductListComponent
            },

            {
                path: 'edit/:id',  //products/edit/1
                component: ProductEditComponent
            },

            {
                path: "create", //products/create
                component: ProductEditComponent
            },

            {
                path: 'search',
                component: ProductSearchComponent
            }
        ]
    }
]

export const productRouting = RouterModule.forRoot(routes);