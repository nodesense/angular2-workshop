import { Injectable } from '@angular/core';

export class CartStorageService {

    constructor(private storage: Storage) {

    }

    addProduct(product: any) {
        let productJson = this.storage.getItem("product." + product.id);

        if (!productJson) {
            let item: any = {
                name: product.name,
                id: product.id,
                quantity: 1
            }

            this.storage.setItem("product." + product.id, JSON.stringify(item));
        } else {
         let item = JSON.parse(productJson);
            item.quantity += 1;
            this.storage.setItem("product." + product.id, JSON.stringify(item));
        }
    }
}

export class CartLocalStorageService extends CartStorageService {
    constructor() {
        super(window.localStorage);
    }
}


export class CartSessionStorageService extends CartStorageService {
    constructor() {
        super(window.sessionStorage);
    }
}