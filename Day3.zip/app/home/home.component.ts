import {Component, OnInit, Inject} from "@angular/core";

import {ProductService} from "../product/product.service";
import {HttpClient} from "../auth/auth.http-client";
import {Response} from "@angular/http";

import "rxjs/Rx";

@Component({
    selector: 'home',
    templateUrl: 'app/home/home.component.html'
})
export class HomeComponent implements OnInit {

    products:any;
    brands:any;

    constructor(private productService:ProductService,
                private httpClient:HttpClient,
                @Inject("apiEndPoint") private apiEndPoint: string) {
 
                }


    getBrands() {
        return  this.httpClient.get(this.apiEndPoint + "/api/brands")
              .map((response: Response)=> response.json())
              .toPromise();
    }

    callBackApproach() {
        this.productService.getProducts()
        .then((data:any) => {
            
            this.getBrands()
            .then((brandData) => {
                this.products = data;
                this.brands = brandData;
            })

        })
    }

    normalApproach() {
        this.productService.getProducts()
        .then((data:any) => {
            this.products = data;
        })

        this.getBrands()
        .then((brandData) => {
            this.brands = brandData;
        })
    }

    promiseApproach() {
        Promise.all([
             this.productService.getProducts(),
             this.getBrands()
        ]).then((results: any) => {
            this.products = results[0];
            this.brands = results[1];
        })
    }

    ngOnInit(){
        //this.normalApproach();
       // this.callBackApproach();
       this.promiseApproach();
    }
}

