import {Component, OnInit} from "@angular/core";
import {ActivatedRoute, Router, Params} from "@angular/router";

import {ProductService} from "./product.service";
//products/edit/1

@Component({
    templateUrl : 'app/product/product-edit.component.html'
})
export class ProductEditComponent implements OnInit {
    product: any = {};

    constructor(private route:ActivatedRoute,
                private router: Router,
                private productService: ProductService
                ) {
    }

    ngOnInit(){
        this.route.params.forEach((params: Params)=> {
            let id = params['id'];
            console.log("id is", id);

            if (id) {
                this.productService.getProduct(id)
                .then((data: any) => this.product = data);
            } else {
                this.product = {};
            }
        });
    }

    saveProduct($event : Event) {
        console.log("save product ", this.product);

        this.productService.saveProduct(this.product)
        .then((data : any) => {
            console.log("From server " , data);
            this.product = data;
        })
    }
 

}