import {Injectable, Inject} from "@angular/core";
import {Http, Response, Headers, RequestOptions} from "@angular/http";

import "rxjs/Rx";

import {HttpClient} from "../auth/auth.http-client";

@Injectable()
export class ProductService {
    constructor(private http:HttpClient,
                @Inject("apiEndPoint") private apiEndPoint:string) {
        console.log("new ProductService created");
        console.log("end point ", apiEndPoint);
    }


    //GET /api/products?q=text
    searchProducts(q: any): any {
        return  this.http.get(this.apiEndPoint + '/api/products?q='+q)
        .map((response: Response) => response.json())
        .toPromise();
    }

    //GET /api/products
    getProducts(): any {
        return  this.http.get(this.apiEndPoint + '/api/products')
        .map((response: Response) => response.json())
        .toPromise();
    }

    //GET /api/products/1
    getProduct(id: any) {
        return this.http.get(this.apiEndPoint + "/api/products/" + id)
        .map((response: Response) => response.json())
        .toPromise();
    }


    //DELETE /api/products/1
    deleteProduct(id: any) {
        return this.http.delete(this.apiEndPoint + "/api/products/" + id)
        .map((response: Response) => response.json())
        .toPromise();
    }

    saveProduct(product: any) {
        let jsonData = JSON.stringify(product);

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        //PUT /api/products/1
        if (product.id) {
            return this.http.put(this.apiEndPoint + '/api/products/' + product.id, 
            jsonData, 
            options)
            .map((response: Response) => response.json())
            .toPromise();
        }

        else {

            return this.http.post(this.apiEndPoint + '/api/products', 
            jsonData, 
            options)
            .map((response: Response) => response.json())
            .toPromise();
            }

        }



    


}