import {Component, OnInit} from "@angular/core";
import {ActivatedRoute, Router, Params} from "@angular/router";

import {ProductService} from "./product.service";

import {AuthService} from "../auth/auth.service";

//products/view/1

@Component({
    templateUrl : 'app/product/product-view.component.html'
})
export class ProductViewComponent implements OnInit {
    product: any;
    isAdmin: boolean = false;

    constructor(private route:ActivatedRoute,
                private router: Router,
                private productService: ProductService,
                private authService: AuthService
                ) {
                    
                    this.isAdmin = this.authService.isAdmin();

    }

    ngOnInit(){
        this.route.params.forEach((params: Params)=> {
            let id = params['id'];
            console.log("id is", id);

            if (id) {
                this.productService.getProduct(id)
                .then((data: any) => this.product = data);
            }
        });
    }

    editProduct() {
        console.log("Edit Product");
        this.router.navigate(["/products/edit/" + this.product.id]);
    }

    deleteProduct() {
        this.productService.deleteProduct(this.product.id)
        .then((data: any) => {
            this.router.navigate(["/products/list"]);
        })
    }

}