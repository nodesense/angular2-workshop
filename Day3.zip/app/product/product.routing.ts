import {RouterModule, Routes} from "@angular/router";
import {ProductListComponent} from "./product-list.component";

import {ProductViewComponent} from "./product-view.component";


import {ProductEditComponent} from "./product-edit.component";

import {AuthGuard, AdminGuard} from "../auth/auth.guards";

const routes: Routes = [
    {
        path: 'products/list',
        component: ProductListComponent,
        canActivate: [AuthGuard]
    },

    {
        path: 'products/view/:id',
        component : ProductViewComponent,
        canActivate: [AuthGuard]
    },

    {
        path: 'products/edit/:id',
        component: ProductEditComponent,
        canActivate: [AuthGuard, AdminGuard]
    },

    {
        path: 'products/create',
        component: ProductEditComponent,
        canActivate: [AuthGuard]
    }
]

export const productRouting = RouterModule.forRoot(routes);

