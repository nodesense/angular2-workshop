import {Component, Input, Output, EventEmitter} from "@angular/core";

@Component({
    selector: 'product-card',
    templateUrl: 'app/product/product-card.component.html'
})
export class ProductCardComponent {
    @Input()
    product: any;

    @Output()
    addToCart:EventEmitter<any> = new EventEmitter<any>();

    onClick() {
        this.addToCart.emit(this.product);
    }
}

