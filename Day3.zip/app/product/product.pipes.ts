import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'byYear'
})
export class ByYearPipe implements PipeTransform {
     
    transform(inputs: any, year: string) {
        console.log("year is ", year);
        
        if (!year) {
            return inputs;
        }

        if (!inputs) {
            return null;
        }

        let results:any = [];

        for(var i = 0; i < inputs.length; i++) {
            if (inputs[i].year == year) {
                results.push(inputs[i]);
            }
        }

        return results;
    }
}


import {ProductService} from "./product.service";

@Pipe({
    name:'searchProduct'
})
export class SearchProductPipe implements PipeTransform {
    constructor(private productService: ProductService) {
    }

    transform(q: any) {
        console.log("Pipe Request ", q);
        return this.productService.searchProducts(q)
    }
}