import {Component, OnInit} from "@angular/core";
import {Http, Response} from "@angular/http";
import {ProductService} from "./product.service";

import {CartStorageSevice} from "../cart/cart.service";

@Component({
    templateUrl: 'app/product/product-list.component.html'
})
export class ProductListComponent implements OnInit{
    products: any = [];

    years: [number] = [2010, 2011, 2012, 2013, 2014, 2015, 2016];

    year: string;
    q:string;

    constructor(private productService: ProductService,
                private cartStorageService: CartStorageSevice
    ) {

    }

    ngOnInit() {
        console.log("ngOnInit");
        this.productService.getProducts()
        .then((data: any) => this.products = data);
    }

    ngOnDestroy() {
        console.log("ngOnDestroy");
    }

    addProductToCart(product: any) {
        console.log("addProductToCart");
        this.cartStorageService.addProduct(product);
    }
}