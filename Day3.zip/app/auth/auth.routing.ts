import {Routes, RouterModule} from "@angular/router";

import {LoginComponent} from "./login.component";

var routes:Routes = [{
  path : 'auth/login',
  component:   LoginComponent
}]

export const authRouting = RouterModule.forRoot(routes);