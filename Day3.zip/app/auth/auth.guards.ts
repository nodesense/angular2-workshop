import {Injectable} from "@angular/core";
import {CanActivate} from '@angular/router';

import {CanDeactivate} from '@angular/router'; 

import {ActivatedRouteSnapshot} from '@angular/router';
import {RouterStateSnapshot} from '@angular/router';
import {Router} from "@angular/router";

import {AuthService} from "./auth.service";

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private router: Router,
                private authService: AuthService) {
        console.log("AuthGuard::constructor");
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        console.log("AuthGuard::canActivate ", Math.random());
        
        console.log("Url is ", state.url);

        if (this.authService.isAuthenticated()) {
            return true;
        }
        
        this.authService.setRedirectUrl(state.url);
        this.router.navigate(['/auth/login']);

        return false; 
    }
}

@Injectable()
export class AdminGuard implements CanActivate {

    constructor(private router: Router,
                private authService: AuthService) {
         console.log("AdminGuard::constructor");
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        console.log("AdminGuard::canActivate ", Math.random());

        console.log('route ', JSON.stringify(route.url));
        console.log('state ', state.url);

        if (this.authService.isAdmin()) {
            return true;
        }
        
        this.router.navigate(['/forbidden']);

        return false;
    }
}
