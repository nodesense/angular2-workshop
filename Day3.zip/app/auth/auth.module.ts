import {NgModule} from "@angular/core";

import { ErrorHandler } from "@angular/core";
import {CommonModule} from "@angular/common";
import {RouterModule} from "@angular/router";
import {FormsModule} from "@angular/forms";

import {authRouting} from "./auth.routing";
import {LoginComponent} from "./login.component";

import {AuthService} from "./auth.service"
import {HttpClient} from "./auth.http-client";

import {AuthGuard, AdminGuard} from "../auth/auth.guards";

@NgModule({
    imports: [CommonModule, RouterModule, FormsModule, authRouting],
    declarations: [LoginComponent],
    providers: [
           AuthService,
           HttpClient,
           AuthGuard, 
           AdminGuard
        ]
})
export class AuthModule {

}