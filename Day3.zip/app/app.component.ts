import { Component, OnInit } from '@angular/core';

import {AuthService} from "./auth/auth.service";

import {Router} from "@angular/router";

@Component({
    selector: 'my-app',
    template: `
           <nav>
            <a routerLink="/">Home</a>
            <a routerLink="/products/list">Products</a>
            <a routerLink="/cart">Cart</a>
            <a routerLink="/about">About</a>

            <span *ngIf="authenticated">Welcome, {{username}}</span>
            
            <a routerLink="/auth/login" *ngIf="!authenticated">Login</a>
            <a  (click)="logout()" *ngIf="authenticated">Logout</a>

           </nav>

           <router-outlet></router-outlet>     

    `
})
export class AppComponent implements OnInit { 
     authenticated: boolean = false;
     username: string;

     constructor(private router:Router,
                 private authService: AuthService) {
        this.authService.getAuthNotification()
        .subscribe((result: boolean) => {
                this.authenticated = result;
                this.username = this.authService.getName();
            });
     }

     ngOnInit() {
         console.log("Is Authenticated ", this.authService.isAuthenticated());
         this.authenticated = this.authService.isAuthenticated();

         this.username = this.authService.getName();
     }

     logout() {
        this.authService.logout();
        this.router.navigate(["/"]);
    }

}

