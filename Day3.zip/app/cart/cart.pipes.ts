import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'citiesByState'
})
export class CitiesByStatePipe implements PipeTransform {
    transform(cities: any, stateId: any) {
        console.log(cities.length);
        console.log(stateId);
        

        var results:any = [];

        for(var i = 0; i < cities.length; i++) {
            if (cities[i].stateId == stateId) {
                results.push(cities[i]);
            }
        }

        return results;
    }
}