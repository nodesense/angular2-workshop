import {Component} from "@angular/core";

import {CartStorageSevice} from "../cart/cart.service";

import {Router} from "@angular/router";

@Component({
    templateUrl: 'app/cart/cart.component.html'
})
export class CartComponent {
    products: any = [];

    constructor(private cartStorageSevice: CartStorageSevice,
                private router: Router
    ) {
        this.products = cartStorageSevice.getProducts(); 
    }

    checkout() {
        let discount: number = Math.floor(Math.random() * 99);
        let couponCode:string = "L&T" + discount.toString();

        this.router.navigate(["/cart/checkout", {'discount': discount, 'coupon': couponCode }]);
    }
}