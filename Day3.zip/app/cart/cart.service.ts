import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
  


export class CartStorageSevice {
  
  constructor(private storage:Storage) {

  }
 
  addProduct(product: any) {
    let productJson = this.storage.getItem("product." + product.id);

    if (!productJson) {
      let item: any = {
        name: product.name,
        id: product.id,
        quantity: 1
      }

      this.storage.setItem("product." + product.id, JSON.stringify(item));
    } else {
      let item = JSON.parse(productJson);
      item.quantity += 1;
       this.storage.setItem("product." + product.id, JSON.stringify(item));
    }
  }

  

  removeProduct(id: any) {
    this.storage.removeItem("product." + id);
  }

  getProducts() {
    let items : any = [];

    for(var key in this.storage) {
      if (key.indexOf("product.") >= 0) {
        items.push(JSON.parse(this.storage.getItem(key)));
      }
    }

    return items;
  }

}

@Injectable()
export class CartLocalStorageService extends CartStorageSevice {
  
  constructor() {
    super(window.localStorage);
  }

}

@Injectable()
export class CartSessionStorageService extends CartStorageSevice {
  
  constructor() {
    super(window.sessionStorage);
  }
  
}
 