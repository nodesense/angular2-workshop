import {Injectable} from "@angular/core";
import {CanDeactivate} from '@angular/router'; 
import {CheckoutComponent} from "./checkout.component";
 
@Injectable()
export class SaveWarningGuard implements CanDeactivate<CheckoutComponent> {
 

  canDeactivate(target: CheckoutComponent) :any {
     

    if(!target.isSaved()){
        //return window.confirm('Do you really want to cancel?');
        return this.sweetAlertConfirmPromise();
    }


    return true;
  }

  sweetAlertConfirmPromise() {
      let promise:Promise<boolean> = new Promise<boolean>(function(resolve, reject){
        swal({   title: "Are you sure?",   
            text: "You will not get this offer again!",   
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "Yes, miss it!",   
            cancelButtonText: "No, I want it!",   
            closeOnConfirm: true,   
            closeOnCancel: true 
        }, 
            function(isConfirm){   
                console.log("called ", isConfirm);

                if (isConfirm) {     
                    resolve(true);
                } else {     
                    resolve(false);
                } 
            }
        );
      });

      return promise;
  }
}