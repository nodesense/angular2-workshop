import {NgModule} from "@angular/core";

import {CommonModule} from "@angular/common";
import {RouterModule} from "@angular/router";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";

import {cartRouting} from "./cart.routing";
import {CartComponent} from "./cart.component";
import {CartStorageSevice, CartLocalStorageService, CartSessionStorageService} from "./cart.service"

@NgModule({
    imports: [CommonModule, RouterModule, cartRouting],
    declarations: [CartComponent],
    providers: [
           {
               provide: CartStorageSevice,
               useClass: CartSessionStorageService
           }
        ]
})
export class CartModule {

}