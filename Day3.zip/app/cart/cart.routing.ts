import {RouterModule, Routes} from "@angular/router";
import {CartComponent} from "./cart.component";
import {CheckoutComponent} from "./checkout.component";

import {SaveWarningGuard} from "./cart.guards";

const routes: Routes = [
    {
        path: 'cart',
        component: CartComponent
    },

    {
        path:'cart/checkout',
        component: CheckoutComponent,
        canDeactivate: [SaveWarningGuard]
    }
]

export const cartRouting = RouterModule.forRoot(routes);